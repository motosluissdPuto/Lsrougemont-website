
import Header from './_header'
import Footer from './_footer'
export default function About(){
  return (
    <>
      <Header/>
      <main className="container section">
        <h1 style={{color:'var(--gold)'}}>About LS Rougemont Luxury Service</h1>
        <p style={{color:'var(--muted)'}}>
          LS Rougemont offers exclusive private transportation in Rougemont, Gstaad and across the Swiss Alps.
          With deep regional knowledge, a discreet client‑focused approach and high‑end vehicles, we provide tailored
          transport solutions for private individuals, hotels, events and executive needs. Every journey is designed with
          comfort, precision and professionalism — from airport transfers to scenic alpine drives.
        </p>
      </main>
      <Footer/>
    </>
  )
}
