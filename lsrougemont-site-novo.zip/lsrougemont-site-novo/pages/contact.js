
import Header from './_header'
import Footer from './_footer'
export default function Contact(){
  return (
    <>
      <Header/>
      <main className="container section" style={{textAlign:'center'}}>
        <h1 style={{color:'var(--gold)'}}>Contact</h1>
        <div className="contact-list" style={{marginTop:16}}>
          <a className="contact-item" href="https://wa.me/41783416888" target="_blank" rel="noreferrer">WhatsApp: +41 78 341 68 88</a>
          <a className="contact-item" href="tel:+41783416888">Phone: +41 78 341 68 88</a>
          <a className="contact-item" href="mailto:info@lsrougemont.ch">Email: info@lsrougemont.ch</a>
        </div>
      </main>
      <Footer/>
    </>
  )
}
