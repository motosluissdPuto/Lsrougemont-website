
import Header from './_header'
import Footer from './_footer'
export default function Home(){
  return (
    <>
      <Header/>
      <section className="hero">
        <h1>Private Luxury Transportation in Rougemont & the Swiss Alps</h1>
        <p>Premium private transfers, tailored alpine tours and executive travel — always discreet, punctual and comfortable.</p>
        <a className="cta" href="https://wa.me/41783416888" target="_blank" rel="noreferrer">Book via WhatsApp</a>
        <div className="hero-img">
          <img src="/images/hero.jpg" alt="LS Rougemont Luxury Service" style={{width:'100%',display:'block'}}/>
        </div>
      </section>
      <main className="container section">
        <div className="grid">
          {[
            {title:'Airport Transfers', text:'Geneva, Zurich, Bern and Sion — door‑to‑door, punctual and discreet.'},
            {title:'Alpine Tours', text:'Scenic drives across Rougemont, Gstaad and the Swiss Alps, tailored to you.'},
            {title:'Events & Weddings', text:'Elegant ground transport with attention to detail.'},
            {title:'Hotel & Ski Resorts', text:'Seamless transfers to chalets and resorts (incl. Glacier 3000).'},
            {title:'Corporate Travel', text:'Executive itineraries with precision and privacy.'},
            {title:'Private Chauffeur', text:'On‑demand driver for local and regional trips.'}
          ].map(s=>(
            <div className="card" key={s.title}>
              <h3>{s.title}</h3>
              <p style={{color:'var(--muted)'}}>{s.text}</p>
            </div>
          ))}
        </div>
      </main>
      <Footer/>
    </>
  )
}
