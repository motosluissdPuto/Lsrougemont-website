
export default function Footer(){
  return(
    <footer className="footer">
      <div>WhatsApp / Phone: +41 78 341 68 88</div>
      <div>Email: info@lsrougemont.ch</div>
      <div style={{marginTop:6,fontSize:12,opacity:.8}}>© {new Date().getFullYear()} LS Rougemont Luxury Service</div>
    </footer>
  )
}
