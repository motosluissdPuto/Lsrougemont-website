
import Header from './_header'
import Footer from './_footer'
export default function Services(){
  const items = [
    {title:'Airport Transfers', img:'/images/plane.jpg', text:'Geneva, Zurich, Bern, Sion — door‑to‑door.'},
    {title:'Alpine Tours', img:'/images/alps.jpg', text:'Private scenic drives tailored to your plans.'},
    {title:'Events & Weddings', img:'/images/event.jpg', text:'Impeccable, elegant logistics for special days.'},
    {title:'Hotel & Ski Resorts', img:'/images/ski.jpg', text:'Chalets and resorts including Glacier 3000.'},
    {title:'Corporate Travel', img:'/images/corporate.jpg', text:'Confidential, precise and reliable.'},
    {title:'Private Chauffeur', img:'/images/local.jpg', text:'On‑demand local and regional service.'}
  ]
  return (
    <>
      <Header/>
      <main className="container section">
        <h1 style={{color:'var(--gold)'}}>Services</h1>
        <div className="grid" style={{marginTop:16}}>
          {items.map(it=>(
            <div className="card" key={it.title}>
              <img src={it.img} alt={it.title} style={{width:'100%',borderRadius:12,marginBottom:12}}/>
              <h3>{it.title}</h3>
              <p style={{color:'var(--muted)'}}>{it.text}</p>
            </div>
          ))}
        </div>
      </main>
      <Footer/>
    </>
  )
}
